#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
		 setlocale(LC_ALL, "Portuguese");
	
printf("\n**************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*          ");
printf("\n* Programa JNP-26 - ...Contar de 1 a 10...*         ");	
printf("\n**************************************************** ");

 int i;

    for(i = 1; i <= 10; i++) {
        printf("%d\n", i);
    }

    return 0;	
	
}
