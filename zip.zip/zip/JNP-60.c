#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                          ");
printf("\n* Programa JNP-60- ... O Validador dos Dias �teis...                 ");	
printf("\n******************************************************************** ");	
	
int dia;

    printf("Digite um n�mero de 1 a 7: ");
    scanf("%d", &dia);

    switch(dia) {
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            printf("Dia �til. Acesso liberado para o trabalho.\n");
            break;

        case 1:
        case 7:
            printf("Fim de Semana. Predio fechado.\n");
            break;

        default:
            printf("N�mero de dia inv�lido.\n");
    }

    return 0;	
}
