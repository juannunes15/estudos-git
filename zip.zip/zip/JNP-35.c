#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main() {
	
setlocale(LC_ALL, "Portuguese");
	
printf("\n********************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                ");
printf("\n* Programa JNP-35 - ...N�meros de Fibonacci...*            ");	
printf("\n********************************************************** ");
	
    int n, i;
    long long a = 0, b = 1, c;

    printf("Digite a quantidade de termos: ");
    scanf("%d", &n);

    printf("Sequencia de Fibonacci:\n");

    for(i = 1; i <= n; i++) {
        printf("%lld ", a);

        c = a + b;
        a = b;
        b = c;
    }

    printf("\n");

    return 0;
}
