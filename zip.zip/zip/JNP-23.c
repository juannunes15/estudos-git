#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*              ");
printf("\n* Programa JNP-23 - ...Maior de dois n�meros...*         ");	
printf("\n******************************************************** ");	
	
 int a, b;

    printf("Digite dois n�meros: ");
    scanf("%d %d", &a, &b);

    if (a > b)
        printf("Maior n�mero: %d\n", a);
    else if (b > a)
        printf("Maior n�mero: %d\n", b);
    else
        printf("Os n�meros s�o iguais.\n");

    return 0;	
		
}
