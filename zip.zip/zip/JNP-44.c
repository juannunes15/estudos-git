#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-44- ...Contar dig�tos de um n�mero...                ");	
printf("\n******************************************************************* ");	
	
int numero, contador = 0;

    printf("Digite um n�mero positivo: ");
    scanf("%d", &numero);

    if (numero == 0) {
        contador = 1;
    } else {
        while (numero > 0) {
            contador++;
            numero /= 10;
        }
    }

    printf("Quantidade de d�gitos: %d\n", contador);

    return 0;	
	
}
