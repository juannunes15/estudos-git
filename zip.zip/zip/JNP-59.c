#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                          ");
printf("\n* Programa JNP-59- ...Assistente de Dire��o...                       ");	
printf("\n******************************************************************** ");

 char direcao;

    printf("Digite uma letra (N, S, L ou O): ");
    scanf(" %c", &direcao);

    switch(direcao) {
        case 'N':
            printf("Seguir para o Norte.\n");
            break;

        case 'S':
            printf("Seguir para o Sul.\n");
            break;

        case 'L':
            printf("Virar a Leste (Direita).\n");
            break;

        case 'O':
            printf("Virar a Oeste (Esquerda).\n");
            break;

        default:
            printf("Comando inv�lido! Pare o rob�.\n");
    }

    return 0;	
    
}
