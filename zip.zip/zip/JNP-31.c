#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n********************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                ");
printf("\n* Programa JNP-31 - ...Contagem regressiva...*             ");	
printf("\n********************************************************** ");
	
 int i;

    for(i = 10; i >= 1; i--) {
        printf("%d\n", i);
    }

    return 0;	
	
}
