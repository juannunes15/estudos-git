#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
setlocale(LC_ALL, "Portuguese");
	
printf("\n****************************************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                                    ");
printf("\n* Programa JNP-42- ...Quantidade de n�meros �mpares digitados...               ");	
printf("\n****************************************************************************** ");	
	
int numero, contador = 0, i = 1;

    while(i <= 10) {
        printf("Digite o %d n�mero: ", i);
        scanf("%d", &numero);

        if(numero % 2 != 0)
            contador++;

        i++;
    }

    printf("Quantidade de �mpares: %d\n", contador);

    return 0;	
		
}

