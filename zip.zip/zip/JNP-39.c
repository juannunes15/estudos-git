#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                   ");
printf("\n* Programa JNP-39- ...Verificar se um n�mero � positivo.      ");	
printf("\n************************************************************* ");		
	
 int numero;

    printf("Digite um n�mero positivo: ");
    scanf("%d", &numero);

    while(numero <= 0) {
        printf("Valor inv�lido. Digite novamente: ");
        scanf("%d", &numero);
    }

    printf("N�mero aceito: %d\n", numero);

    return 0;	
	
}
