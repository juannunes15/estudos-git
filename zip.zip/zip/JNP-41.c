#include<stdio.h>
#include<stdio.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                   ");
printf("\n* Programa JNP-41- ...N�mero primo com while...               ");	
printf("\n************************************************************* ");	
	
int numero, i = 1, divisores = 0;

    printf("Digite um n�mero: ");
    scanf("%d", &numero);

    while(i <= numero) {
        if(numero % i == 0)
            divisores++;

        i++;
    }

    if(divisores == 2)
        printf("N�mero primo.\n");
    else
        printf("N�mero n�o primo.\n");

    return 0;	
	
}
