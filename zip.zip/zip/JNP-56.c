#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                          ");
printf("\n* Programa JNP-56- ...O menu do fast-food digital...                 ");	
printf("\n******************************************************************** ");	
	
int opcao;

    printf("Escolha um combo (1 a 4): ");
    scanf("%d", &opcao);

    switch(opcao) {
        case 1:
            printf("Combo Hamburguer + Batata + Refri - R$ 30,00\n");
            break;

        case 2:
            printf("Combo Pizza Brotinho + Refri - R$ 25,00\n");
            break;

        case 3:
            printf("Combo Salada + Suco Natural - R$ 22,00\n");
            break;

        case 4:
            printf("Combo Balde de Frango + Molho - R$ 35,00\n");
            break;

        default:
            printf("Opcao inv�lida! Escolha de 1 a 4.\n");
    }

    return 0;
		
}
