#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                   ");
printf("\n* Programa JNP-37- ...Soma de n�meros at� digitar zero...*    ");	
printf("\n************************************************************* ");		
	
int numero, soma = 0;

    printf("Digite n�meros (0 para parar):\n");

    scanf("%d", &numero);

    while(numero != 0) {
        soma += numero;
        scanf("%d", &numero);
    }

    printf("Soma total = %d\n", soma);

    return 0;	

}
