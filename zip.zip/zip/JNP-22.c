#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");
	
printf("\n*********************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*     ");
printf("\n* Programa JNP-22 - ...Par ou �mpar...*         ");	
printf("\n*********************************************** ");
	
	int numero;

    printf("Digite um n�mero: ");
    scanf("%d", &numero);

    if (numero % 2 == 0)
        printf("Par.\n");
    else
        printf("�mpar.\n");

    return 0;	

}
