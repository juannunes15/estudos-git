#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");
	 
printf("\n********************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880    ");
printf("\n* Programa JNP-16 - ...M�ltiplo de 3 ou 5...* ");	
printf("\n********************************************* ");
	
	 int numero;

    printf("Digite o n�mero do pedido: ");
    scanf("%d", &numero);

    if (numero % 3 == 0 && numero % 5 == 0)
        printf("Ganhou refrigerante e sobremesa.\n");
    else if (numero % 3 == 0)
        printf("Ganhou refrigerante.\n");
    else if (numero % 5 == 0)
        printf("Ganhou sobremesa.\n");
    else
        printf("N�o ganhou brindes.\n");

    return 0;
	
	
}
