#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n********************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                ");
printf("\n* Programa JNP-30 - ...Fatorial de um n�mero...*           ");	
printf("\n********************************************************** ");

int numero, i;
    long long fatorial = 1;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    for(i = 1; i <= numero; i++) {
        fatorial *= i;
    }

    printf("Fatorial = %lld\n", fatorial);

    return 0;
	
}
