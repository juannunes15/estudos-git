#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-49- ...Pedir senha at� acertar...                    ");	
printf("\n******************************************************************* ");	
	
int senha;

    do {
        printf("Digite a senha: ");
        scanf("%d", &senha);

    } while (senha != 1111);

    printf("Acesso liberado!\n");

    return 0;	
	
}
