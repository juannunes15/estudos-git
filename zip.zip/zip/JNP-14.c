#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

	 setlocale(LC_ALL, "Portuguese");
printf("\n*********************************************");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880   ");
printf("\n* Programa JNP-14 - ...Tipo de Tri�ngulo...* ");	
printf("\n******************************************** ");	


    float a, b, c;

    printf("Digite os tres lados do tri�ngulo: ");
    scanf("%f %f %f", &a, &b, &c);

    if (a == b && b == c) {
        printf("Tri�ngulo Equilatero\n");
    } else if (a == b || a == c || b == c) {
        printf("Tri�ngulo Isosceles\n");
    }
    else {
        printf("Tri�ngulo Escaleno\n");
    }

    return 0;
}
