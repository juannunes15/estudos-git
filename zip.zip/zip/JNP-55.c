#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){

 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                                                 ");
printf("\n* Programa JNP-55- ...Ler n�meros e mostrar o maior(at� digitar neativo)...                 ");	
printf("\n******************************************************************************************* ");

int numero, maior = 0;

    do {
        printf("Digite um n�mero (negativo para sair): ");
        scanf("%d", &numero);

        if(numero >= 0 && numero > maior)
            maior = numero;

    } while(numero >= 0);

    printf("Maior n�mero informado: %d\n", maior);

    return 0;
    
}
