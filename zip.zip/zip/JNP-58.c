#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                          ");
printf("\n* Programa JNP-58- ...A Calculadora de Bolso de 4 opera��es...       ");	
printf("\n******************************************************************** ");		
	
 float a, b, resultado;
    char op;

    printf("Digite dois n�meros: ");
    scanf("%f %f", &a, &b);

    printf("Digite a opera��o (+ - * /): ");
    scanf(" %c", &op);

    switch(op) {
        case '+':
            resultado = a + b;
            printf("Resultado = %.2f\n", resultado);
            break;

        case '-':
            resultado = a - b;
            printf("Resultado = %.2f\n", resultado);
            break;

        case '*':
            resultado = a * b;
            printf("Resultado = %.2f\n", resultado);
            break;

        case '/':
            if(b != 0)
                printf("Resultado = %.2f\n", a / b);
            else
                printf("Divis�o por zero n�o permitida.\n");
            break;

        default:
            printf("Opera��o matem�tica n�o reconhecida.\n");
    }

    return 0;	
	
}
