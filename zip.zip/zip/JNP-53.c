#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-53- ...Confirmar sa�da com 's'...                    ");	
printf("\n******************************************************************* ");	
	
 char sair;

    do {
        printf("Executando opera��o...\n");
        printf("Deseja sair? (s/n): ");
        scanf(" %c", &sair);

    } while (sair != 's' && sair != 'S');

    printf("Programa encerrado.\n");

    return 0;	
    
}
