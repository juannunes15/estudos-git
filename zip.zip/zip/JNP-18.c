#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include<string.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880        ");
printf("\n* Programa JNP-18 - ...Login Simples...          ");	
printf("\n************************************************* ");

 char usuario[20];
    char senha[20];

    printf("Usu�rio: ");
    scanf("%s", usuario);

    printf("Senha: ");
    scanf("%s", senha);

    if (strcmp(usuario, "aluno") == 0 &&
        strcmp(senha, "1234") == 0)
        printf("Acesso permitido.\n");
    else
        printf("Acesso negado.\n");

    return 0;

}
