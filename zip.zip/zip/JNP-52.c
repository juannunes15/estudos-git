#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-52- ...Soma at� o n�mero ser m�ltiplo de 10...       ");	
printf("\n******************************************************************* ");

 int numero, soma = 0;

    do {
        printf("Digite um n�mero: ");
        scanf("%d", &numero);

        soma += numero;

    } while (numero % 10 != 0);

    printf("Soma total = %d\n", soma);

    return 0;	
    
}
