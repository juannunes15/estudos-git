#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-51- ...Contagem regressiva de 10 at� 1...            ");	
printf("\n******************************************************************* ");	
	
int i = 10;

    do {
        printf("%d\n", i);
        i--;
    } while (i >= 1);

    return 0;
		
}
