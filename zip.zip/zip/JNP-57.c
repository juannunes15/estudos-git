#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                          ");
printf("\n* Programa JNP-57- ...Central do Brinquendo Eletr�nico...            ");	
printf("\n******************************************************************** ");	
	
   int cor;

    printf("Escolha a cor:\n");
    printf("1 - Verde\n");
    printf("2 - Amarelo\n");
    printf("3 - Vermelho\n");
    printf("Digite a opcao: ");
    scanf("%d", &cor);

    switch (cor) {
        case 1:
            printf("O urso diz: Vamos brincar la fora!\n");
            break;

        case 2:
            printf("O urso diz: Estou ficando com soninho...\n");
            break;

        case 3:
            printf("O urso diz: Estou com fome, hora do lanche!\n");
            break;

        default:
            printf("Cor desconhecida\n");
    }

    return 0;
    
}
