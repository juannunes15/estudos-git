#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-54- ...Validar n�mero entre 1 e 5...                 ");	
printf("\n******************************************************************* ");		
	
int numero;

    do {
        printf("Digite um n�mero entre 1 e 5: ");
        scanf("%d", &numero);

        if(numero < 1 || numero > 5)
            printf("Valor inv�lido!\n");

    } while(numero < 1 || numero > 5);

    printf("N�mero v�lido: %d\n", numero);

    return 0;
		
}
