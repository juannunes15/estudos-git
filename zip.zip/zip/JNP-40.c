#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                   ");
printf("\n* Programa JNP-40- ...Tabuada com while...                    ");	
printf("\n************************************************************* ");		
	
int numero, i = 1;

    printf("Digite um n�mero: ");
    scanf("%d", &numero);

    while(i <= 10) {
        printf("%d x %d = %d\n", numero, i, numero * i);
        i++;
    }

    return 0;	
		
}
