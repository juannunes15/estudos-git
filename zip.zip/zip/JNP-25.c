#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");
	
printf("\n**************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*          ");
printf("\n* Programa JNP-25 - ...Notas e aprova��o...*         ");	
printf("\n**************************************************** ");

float media;

    printf("Digite a m�dia final: ");
    scanf("%f", &media);

    if (media >= 7)
        printf("Aprovado.\n");
    else if (media >= 5)
        printf("Recupera��o.\n");
    else
        printf("Reprovado.\n");

    return 0;	
		
}
