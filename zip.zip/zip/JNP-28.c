#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
				 setlocale(LC_ALL, "Portuguese");
	
printf("\n************************************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                                ");
printf("\n* Programa JNP-28 - ...Soma dos 100 primeiros n�meros naturais...*         ");	
printf("\n************************************************************************** ");
	
	  int i, soma = 0;

    for(i = 1; i <= 100; i++) {
        soma += i;
    }

    printf("Soma = %d\n", soma);

    return 0;
	
}
