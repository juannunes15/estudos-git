#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");

printf("\n************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*        ");
printf("\n* Programa JNP-20 - ...Ano Bissexto...*         ");	
printf("\n************************************************** ");

int ano;

    printf("Digite um ano: ");
    scanf("%d", &ano);

    if ((ano % 4 == 0 && ano % 100 != 0) ||
        (ano % 400 == 0))
        printf("Ano bissexto.\n");
    else
        printf("Ano nao bissexto.\n");

    return 0;

}




