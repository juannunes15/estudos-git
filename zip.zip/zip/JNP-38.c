#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                   ");
printf("\n* Programa JNP-38- ...Senha correta...*                       ");	
printf("\n************************************************************* ");		
	
int senha;

    printf("Digite a senha: ");
    scanf("%d", &senha);

    while(senha != 1234) {
        printf("Senha incorreta. Tente novamente: ");
        scanf("%d", &senha);
    }

    printf("Acesso liberado.\n");

    return 0;	
		
}
