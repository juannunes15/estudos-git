#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");
	
printf("\n********************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                ");
printf("\n* Programa JNP-29 - ...N�meros pares de 0 a 50...*         ");	
printf("\n********************************************************** ");
	
    int i;

    for(i = 0; i <= 50; i += 2) {
        printf("%d\n", i);
    }

    return 0;
	
}
