#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");

printf("\n************************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                    ");
printf("\n* Programa JNP-21 - ...Numero positivo ou negativo...*         ");	
printf("\n************************************************************** ");

	float numero;

    printf("Digite um n�mero: ");
    scanf("%f", &numero);

    if (numero > 0)
        printf("Positivo.\n");
    else if (numero < 0)
        printf("Negativo.\n");
    else
        printf("Zero.\n");

    return 0;
	
}



