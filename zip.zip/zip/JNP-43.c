#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-43- ...Soma dos pares entre 1 e 100...               ");	
printf("\n******************************************************************* ");	
	
int numero = 2;
    int soma = 0;

    while(numero <= 100) {
        soma += numero;
        numero += 2;
    }

    printf("Soma dos pares = %d\n", soma);

    return 0;	
		
}
