#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){

   setlocale(LC_ALL, "Portuguese");
	
printf("\n********************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*    ");
printf("\n* Programa JNP-24 - ...Pode votar?...*         ");	
printf("\n********************************************** ");

 int idade;

    printf("Digite sua idade: ");
    scanf("%d", &idade);

    if (idade >= 16)
        printf("Pode votar.\n");
    else
        printf("N�o pode votar.\n");

    return 0;

}
