#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-45- ...Menu at� escolher sair...                     ");	
printf("\n******************************************************************* ");	
	
int opcao = 0;

    while (opcao != 3) {
        printf("\nMENU\n");
        printf("1 - Consultar\n");
        printf("2 - Cadastrar\n");
        printf("3 - Sair\n");
        printf("Opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1)
            printf("Consulta realizada.\n");
        else if (opcao == 2)
            printf("Cadastro realizado.\n");
        else if (opcao == 3)
            printf("Encerrando...\n");
        else
            printf("Opcao inv�lida.\n");
    }

    return 0;	
		
}
