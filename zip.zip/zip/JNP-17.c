#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");
	
printf("\n****************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880             ");
printf("\n* Programa JNP-17 - ...O Sensor do Parque Tem�tico...* ");	
printf("\n****************************************************** ");

 int altura;

    printf("Digite a altura em cent�metros: ");
    scanf("%d", &altura);

    if (altura >= 140)
        printf("Liberado para entrar.\n");
    else
        printf("Entrada n�o permitida.\n");

    return 0;
}
