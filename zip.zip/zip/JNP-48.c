#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-48- ...Menu com op��o de sair...                     ");	
printf("\n******************************************************************* ");	
	
int opcao;

    do {
        printf("\n1 - Mensagem\n");
        printf("2 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &opcao);

        if (opcao == 1)
            printf("Voc� escolheu a mensagem!\n");

    } while (opcao != 2);

    printf("Programa encerrado.\n");

    return 0;	
}
