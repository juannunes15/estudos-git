#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                   ");
printf("\n* Programa JNP-36 - ...Contar at� 10 com while...*            ");	
printf("\n************************************************************* ");		
	
int i = 1;

    while(i <= 10) {
        printf("%d\n", i);
        i++;
    }

    return 0;	
	
}
