#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n********************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                ");
printf("\n* Programa JNP-33 - ...M�ltiplos de 3 entre 1 e 30...*     ");	
printf("\n********************************************************** ");	
	
 int i;

    printf("Multiplos de 3 entre 1 e 30:\n");

 for(i = 1; i <= 30; i++) {
   if(i % 3 == 0) {
    printf("%d\n", i);
    }
    }

    return 0;

}
