#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");

printf("\n************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*        ");
printf("\n* Programa JNP-19 - ...Ordem Crescente...*         ");	
printf("\n************************************************** ");

int a, b, c, temp;

    printf("Digite tr�s n�meros: ");
    scanf("%d %d %d", &a, &b, &c);

    if (a > b) {
        temp = a;
        a = b;
        b = temp;
    }

    if (a > c) {
        temp = a;
        a = c;
        c = temp;
    }

    if (b > c) {
        temp = b;
        b = c;
        c = temp;
    }

    printf("Ordem crescente: %d %d %d\n", a, b, c);

    return 0;


}
