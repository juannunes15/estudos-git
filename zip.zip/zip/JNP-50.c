#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                         ");
printf("\n* Programa JNP-50- ...N�mero positivo obrigat�rio...                ");	
printf("\n******************************************************************* ");	

int numero;

    do {
        printf("Digite um n�mero positivo: ");
        scanf("%d", &numero);

    } while (numero <= 0);

    printf("N�mero aceito: %d\n", numero);

    return 0;
		
}
