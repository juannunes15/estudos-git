#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
 setlocale(LC_ALL, "Portuguese");
	
printf("\n************************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*                   ");
printf("\n* Programa JNP-34 - ...Verificar se um n�mero � primo...*     ");	
printf("\n************************************************************* ");	
	
int numero, i, divisores = 0;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    for(i = 1; i <= numero; i++) {
        if(numero % i == 0) {
            divisores++;
        }
    }

    if(divisores == 2)
        printf("Numero primo.\n");
    else
        printf("Numero nao primo.\n");

    return 0;	

}
