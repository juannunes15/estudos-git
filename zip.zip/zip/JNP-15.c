#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
	 setlocale(LC_ALL, "Portuguese");
	
printf("\n*********************************************************** ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880                  ");
printf("\n* Programa JNP-15 - ...Quantas caixas cabem no caminh�o...* ");	
printf("\n*********************************************************** ");	



    float altCam, largCam, compCam;
    float altCx, largCx, compCx;
    int qtd;

    printf("Altura, largura e comprimento do caminh�o: ");
    scanf("%f %f %f", &altCam, &largCam, &compCam);

    printf("Altura, largura e comprimento da caixa: ");
    scanf("%f %f %f", &altCx, &largCx, &compCx);

    qtd = (int)(altCam / altCx) *
          (int)(largCam / largCx) *
          (int)(compCam / compCx);

    printf("Quantidade de caixas: %d\n", qtd);

    return 0;
		
	
} 
