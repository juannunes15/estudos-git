#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){
	
			 setlocale(LC_ALL, "Portuguese");
	
printf("\n******************************************************* ");
printf("\n* Aluno: Juan Nunes da Paix�o - RA 0025880*             ");
printf("\n* Programa JNP-27 - ...Tabuada de um n�mero...*         ");	
printf("\n******************************************************* ");
	
	int numero, i;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    for(i = 1; i <= 10; i++) {
        printf("%d x %d = %d\n", numero, i, numero * i);
    }

    return 0;	
	
}
